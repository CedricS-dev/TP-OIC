/********************************************************
# Nom ......... : api.js
# Rôle ........ : Code JavaScript pour interagir avec l'API du Met Museum
# Auteur ...... : Cedric SAGHI
# Version ..... : V0.1 du 12/03/2025
# Licence ..... : Réalisé dans le cadre du cours outils collaboratifs, chapitre 2, L1 informatique
# (../..)
# Compilation : aucune
# Usage : Pour exécuter : Lancer le fichier index.html dans le navigateur
#********************************************************/


/**
 * Formate une chaîne de caractères pour que chaque mot soit en minuscule
 * et commence par une majuscule
 * @param {String} nom - Chaîne à formatter
 * @returns {String}   - Chaîne formatée
 */
function formate_nom(nom) 
{
  let result = "";
  // Retire les espaces indésirables en début et fin de chaîne 
  nom = nom.trim();
  // Découpe la chaîne en fonction des espaces
  const noms = nom.split(" ");
  // Pour chaque mot dans la liste
  for (let mot of noms)
  {
    // Si le mot n'est pas un espace ou une chaîne vide
    if (mot != " " && mot != "")
    {
      // Met tous les caractères en minuscule, sauf le premier en majuscule
      mot = mot.toLowerCase();
      mot = mot.charAt(0).toUpperCase() + mot.slice(1);
      // Concatène le mot dans la chaine avec un espace
      result = result.concat(mot , " ");
    }
  }
  // Retourne la chaîne result en retirant l'espace en trop à la fin
  return result.trim();
}


/**
 * Effectue une requête de recherche sur le site Met Museum en utilisant l'entrée utilisateur dans un formulaire HTML
 * Puis lance la fonction get_artwork() sur chaque ID d'œuvre trouvée
 */
async function get_artist()
{
  // Récupère le nom donné dans le formulaire de recherche
  let artist_name = document.getElementById("recherche").value;
  artist = formate_nom(artist_name)
  console.log(artist)
  // Et construit l'URL de la recherche avec ce nom
  const url = `https://collectionapi.metmuseum.org/public/collection/v1/search?artistOrCulture=true&q=${artist}`;

  // Récupère la div galerie et vide son contenu
  const galerie = document.getElementById("galerie");
  galerie.innerHTML = "" ;
  // Récupère le titre de la page
  let titre = document.getElementById("artist-name");
 
  // Essai de lancer la requête
  try {
    const reponse = await fetch(url);
    // Si la propriété "ok" ne vaut pas true, retourne une erreur dans la console
    if(reponse.ok != true)
    {
      throw new Error("Erreur d'accès à l'API.(artiste)");
    }
    // Attends la réponse et récupère la liste des identifiants des œuvres
    const data = await reponse.json();
    if (data.objectIDs == null) 
    {
      titre.innerHTML = `Aucune œuvre n'a été trouvée pour l'artiste ${artist} au Met Museum`;
    } else {
      titre.innerHTML = `Œuvres de l'artiste ${artist} au Met Museum`;

      const id_list = data.objectIDs;
      // Pour chaque identifiant, lance la fonction get_artwork()
      for (const id of id_list)
      {
        get_artwork(id, artist, galerie);
      }
    }
  }
  // Si la requête a échoué, retourne l'erreur dans la console
  catch (error) {
    console.log(error);
  }
}


/**
 * Crée et injecte une carte HTLM dans une galerie à partir de l'ID de l'œuvre
 * @param {Number} id - ID de l'œuvre
 * @param {String} artist - Nom de l'artiste
 * @param {Object} galerie - Élément HTML où la carte doit être insérée
 */
async function get_artwork(id, artist, galerie)
{
  // Essai de lancer la requête
  try {
    const reponse = await fetch(`https://collectionapi.metmuseum.org/public/collection/v1/objects/${id}`);
     // Si la propriété "ok" ne vaut pas true, retourne une erreur dans la console
    if(reponse.ok != true)
    {
      throw new Error("Erreur d'accès à l'API (œuvre).");
    }
    // Attends la réponse et récupère la liste des données de l'œuvre
    const data = await reponse.json();
    // Si le nom de l'artiste correspond et qu'une image existe
    if (data.artistDisplayName.includes(artist))
    {
      // Crée une carte avec ce code HTML
      card = `
        <div class="card">
          <div class="img">
            <img src="${data.primaryImageSmall}" alt="${data.title}">
          </div>
          <div class="card-info">
            <h2>${data.title}</h2>
            <h3>${data.artistDisplayName}</h3>
            <p>${data.objectDate} - ${data.medium} - ${data.dimensions}</p>
            <a href="${data.objectURL}" target="_blank">Voir sur metmuseum.org</a>
          </div>
        </div>
      `;
      // Et insère cette carte dans la galerie
      galerie.insertAdjacentHTML("beforeend", card);
    }
  }  
  // Si la requête a échoué, retourne l'erreur dans la console
  catch (error) {
    console.log(error);
  }
}
