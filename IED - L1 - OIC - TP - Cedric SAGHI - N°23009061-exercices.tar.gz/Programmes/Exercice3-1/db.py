#********************************************************
# Nom ......... : db.py
# Rôle ........ : Code Python pour créer une BDD d'album avec FastAPI et SQLite - Modèles, schémas et BDD
# Auteur ...... : Cedric SAGHI
# Version ..... : V0.1 du 25/04/2025
# Licence ..... : Réalisé dans le cadre du cours outils collaboratifs, chapitre 3, L1 informatique
# (../..)
# Compilation : aucune
# Usage : Pour exécuter : uvicorn main:app --reload
#********************************************************


from sqlmodel import Field, Session, SQLModel, create_engine, Relationship
from typing import Optional


# Classes de base, contiennent les éléments visibles dans -presque- tous les modèles 
class ArtisteBase(SQLModel) :
  nom: str

class GenreBase(SQLModel) :
  nom: str

class AlbumBase(SQLModel) :
  titre: str
  annee: int
  nbr_pistes: int
  artiste_id : int | None = Field(default=None, foreign_key="artiste.id")
  genre_id : int | None = Field(default=None, foreign_key="genre.id")


# Classes "table", héritent de leur version base et font lien avec la BDD
# l'id est géré par la BDD, ainsi que les différentes relations
class Artiste(ArtisteBase, table=True) :
  id: Optional[int] | None = Field(default=None, primary_key=True)
  albums: list["Album"] = Relationship(back_populates="artiste")

class Genre(GenreBase, table=True) :
  id: Optional[int] | None = Field(default=None, primary_key=True)
  albums: list["Album"] = Relationship(back_populates="genre")

class Album(AlbumBase, table=True) :
  id: Optional[int] | None = Field(default=None, primary_key=True)
  artiste: Artiste | None = Relationship(back_populates="albums")
  genre: Genre | None = Relationship(back_populates="albums")
 

# Classes de créations, renvoient simplement les champs que l'utilisateur peut entrer
class ArtisteCreate(ArtisteBase) :
  pass

class GenreCreate(GenreBase) :
  pass

class AlbumCreate(AlbumBase) :
  pass


# Classes de modifications, reprennent les classes de base mais avec tous les champs optionnels
# l'uilisateur peut ainsi ne changer que les champs voulu
class ArtisteUpdate(SQLModel) :
  nom: str | None = None

class GenreUpdate(SQLModel) :
  nom: str | None = None

class AlbumUpdate(SQLModel) :
  titre: str | None = None
  annee: int | None = None
  nbr_pistes: int | None = None
  artiste_id : int | None = None
  genre_id : int | None = None


# Classes publiques, affichent les ids en tant que champs obligatoires
class ArtistePublic(ArtisteBase) :
  id: int

class GenrePublic(GenreBase) :
  id: int

class AlbumPublic(AlbumBase) :
  id: int 


# Classes d'affichages de données
# utilisées pour afficher les relations en évitant les boucles infines dans les requètes
class ArtistePublicWithAlbums(ArtistePublic) :
  albums:list[AlbumPublic] = []

class GenrePublicWithAlbums(GenrePublic) :
  albums:list["AlbumPublicWithArtiste"] = []

class AlbumPublicWithArtiste(AlbumPublic) :
  artiste : ArtistePublic | None = None

class AlbumPublicWithArtisteAndGenre(AlbumPublicWithArtiste) :
  genre: GenrePublic | None = None


# Nom et url de la BDD
database_name = "BDDMusique.db"
sqlite_url = f"sqlite:///{database_name}"

# Création et connection à la BDD
engine = create_engine(sqlite_url)
SQLModel.metadata.create_all(engine)

# Overture de la session pour intéragir avec la BDD (injection de dépendance)
def get_session():
  with Session(engine) as session:
    yield session