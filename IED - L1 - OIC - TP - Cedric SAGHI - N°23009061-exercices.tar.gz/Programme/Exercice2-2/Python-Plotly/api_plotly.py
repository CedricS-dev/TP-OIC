#********************************************************
# Nom ......... : api_plotly.py
# Rôle ........ : Code Python lançant des requêtes sur l'API du Met Museum pour 
# créer un graphique de répartition d'œuvres par départements
# Auteur ...... : Cedric SAGHI
# Version ..... : V0.1 du 07/03/2025
# Licence ..... : Réalisé dans le cadre du cours outils collaboratifs, chapitre 2, L1 informatique
# (../..)
# Compilation : aucune
# Usage : Pour exécuter : python3 api_plotly.py
#******************************************************** 


import requests
import json
from plotly.graph_objs import Bar
from plotly import offline

#  Commence par récupérer la liste des départements du Met Museum
url = 'https://collectionapi.metmuseum.org/public/collection/v1/departments'
r = requests.get(url)
print(f"Status code : {r.status_code}")

# Enregistre la réponse 
reponse = r.json()

# Récupère la liste des départements à partir de la réponse
departments = reponse['departments']
# Crée un dictionnaire pour stocker les résultats
department_list = {}

# Pour chaque numéro de département
# Lance une nouvelle requête et récupère la réponse
for department in departments :
  ID = department['departmentId']
  # Insère l'ID dans l'URL et lance la requête
  search = f"https://collectionapi.metmuseum.org/public/collection/v1/objects?departmentIds={ID}"
  result = requests.get(search)
  reponse = result.json()

  # Insère le nom du département avec son nombre total d'œuvres dans le dictionnaire
  department_list[department["displayName"]] = reponse["total"]

# Puis réorganise le dictionnaire dans l'ordre décroissant des nombres d'œuvres
department_list_order = {k: v for k, v in sorted(department_list.items(), key=lambda item: item[1], reverse=True)}

# Construit le graphique :
data = [{
  'type': 'bar' ,
  'x': list(department_list_order.keys()),
  'y': list(department_list_order.values()),
  'text': list(department_list_order.values()),
}]

mon_agencement = {
'title': "Nombre d'œuvres dans chaque département du Met Museum",
'titlefont': {'size': 28},
'xaxis': { 
  'title': "Nom du Département",
  'titlefont': {'size': 24},
  'tickfont': {'size': 14},
  },
'yaxis': { 
  'title': "Nombre d'Œuvres",
  'titlefont': {'size': 24},
  'tickfont': {'size': 14},     
},}

fig = {'data': data, 'layout': mon_agencement}
offline.plot(fig, filename='met_museum.html')
