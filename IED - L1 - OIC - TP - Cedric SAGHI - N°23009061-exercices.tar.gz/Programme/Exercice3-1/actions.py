#********************************************************
# Nom ......... : actions.py
# Rôle ........ : Code Python pour créer une BDD d'album avec FastAPI et SQLite - Fonction générales
# Auteur ...... : Cedric SAGHI
# Version ..... : V0.1 du 25/04/2025
# Licence ..... : Réalisé dans le cadre du cours outils collaboratifs, chapitre 3, L1 informatique
# (../..)
# Compilation : aucune
# Usage : Pour exécuter : uvicorn main:app --reload
#********************************************************


from sqlmodel import select
from fastapi import HTTPException

# Fonction de création d'un élément
def create(objet, objet_class, session) :
  db_objet = objet_class.model_validate(objet)
  session.add(db_objet)
  session.commit()
  session.refresh(db_objet)
  return db_objet


# Fonction retournant tous les éléments
def read(objet_class, session) :
  objets = session.exec(select(objet_class)).all()
  return objets


# Fonction retournant un élément selon son id
def read_one(objet_id, objet_class, session) :
  objet = session.get(objet_class, objet_id)
  if not objet:
      raise HTTPException(status_code=404, detail="Aucun résultat n'a été trouvé.")
  
  return objet


# Fonction modifiant un élément selon son id
def update(objet_id, objet_class, objet, session) :
  db_objet = session.get(objet_class, objet_id)
  if not db_objet:
    raise HTTPException(status_code=404, detail="Aucun résultat n'a été trouvé.")

  objet_data = objet.model_dump(exclude_unset=True)
  db_objet.sqlmodel_update(objet_data)
  session.add(db_objet)
  session.commit()
  session.refresh(db_objet)
  return db_objet


# Fonction supprimant un élément selon son id
def delete(objet_id, objet_class, session) :
  objet = session.get(objet_class, objet_id)
  if not objet:
    raise HTTPException(status_code=404, detail="Aucun résultat n'a été trouvé.")
  
  session.delete(objet)
  session.commit()
  return {"supression": "L'élément a été supprimé avec succès."}