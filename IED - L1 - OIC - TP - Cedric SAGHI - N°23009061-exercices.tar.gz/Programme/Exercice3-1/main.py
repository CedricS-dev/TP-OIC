#********************************************************
# Nom ......... : main.py
# Rôle ........ : Code Python pour créer une BDD d'album avec FastAPI et SQLite - App et points d'entrées
# Auteur ...... : Cedric SAGHI
# Version ..... : V0.1 du 25/04/2025
# Licence ..... : Réalisé dans le cadre du cours outils collaboratifs, chapitre 3, L1 informatique
# (../..)
# Compilation : aucune
# Usage : Pour exécuter : uvicorn main:app --reload
#********************************************************


from fastapi import Depends, FastAPI
import db 
from actions import *

# Création de l'application FastAPI
app = FastAPI()


@app.get("/")
async def root() :
  return {"message": "Bonjour et Bienvenue sur ma Base de Données Musicale"}


#########################################
#                CRÉATION               #
#########################################


# Crée un artiste
@app.post("/artistes/", response_model=db.ArtistePublic)
async def create_artiste(artiste: db.ArtisteCreate, session: db.Session = Depends(db.get_session)) :
  return create(artiste, db.Artiste, session)


# Crée un un album
@app.post("/albums/", response_model=db.AlbumPublicWithArtisteAndGenre)
async def create_album(album: db.AlbumCreate, session: db.Session = Depends(db.get_session)) :
  return create(album, db.Album, session)


# Crée un un genre
@app.post("/genres/", response_model=db.GenrePublic)
async def create_genre(genre: db.GenreCreate, session: db.Session = Depends(db.get_session)) :
  return create(genre, db.Genre, session)


#########################################
#            LISTE COMPLÈTE             #
#########################################


# Retourne tous les artistes
@app.get("/artistes/", response_model=list[db.ArtistePublicWithAlbums])
async def read_artistes(session: db.Session = Depends(db.get_session)) :
  return read(db.Artiste, session)


# Retourne tous les albums
@app.get("/albums/", response_model=list[db.AlbumPublicWithArtisteAndGenre])
async def read_albums(session: db.Session = Depends(db.get_session)) :
  return read(db.Album, session)


# Retourne tous les genres
@app.get("/genres/", response_model=list[db.GenrePublic])
async def read_genres(session: db.Session = Depends(db.get_session)) :
  return read(db.Genre, session)
  

#########################################
#              UN ÉLÉMENT               #
#########################################


# Retourne un artiste selon son id
@app.get("/artistes/{artiste_id}", response_model=db.ArtistePublicWithAlbums)
async def read_artiste(artiste_id: int, session: db.Session = Depends(db.get_session)) :
  return read_one(artiste_id, db.Artiste, session)


# Retourne un album selon son id
@app.get("/albums/{album_id}", response_model=db.AlbumPublicWithArtisteAndGenre)
async def read_album(album_id: int, session: db.Session = Depends(db.get_session)) :
  return read_one(album_id, db.Album, session)
 

# Retourne un genre selon son id
@app.get("/genres/{genre_id}", response_model=db.GenrePublicWithAlbums)
async def read_genre(genre_id: int, session: db.Session = Depends(db.get_session)) :
  return read_one(genre_id, db.Genre, session)
  

#########################################
#             MODIFICATION              #
#########################################


# Modifie un artiste
@app.patch("/artistes/{artiste_id}", response_model=db.ArtistePublic)
async def update_artiste(artiste_id: int, artiste: db.ArtisteUpdate, session: db.Session = Depends(db.get_session)) :
  return update(artiste_id, db.Artiste, artiste, session)


# Modifie un album
@app.patch("/albums/{album_id}", response_model=db.AlbumPublicWithArtisteAndGenre)
async def update_album(album_id: int, album: db.AlbumUpdate, session: db.Session = Depends(db.get_session)) :
  return update(album_id, db.Album, album, session)


# Modifie un genre
@app.patch("/genres/{genre_id}", response_model=db.GenrePublicWithAlbums)
async def update_genre(genre_id: int, genre: db.GenreUpdate, session: db.Session = Depends(db.get_session)) :
  return update(genre_id, db.Genre, genre, session)


#########################################
#              SUPPRESSION              #
#########################################


# Supprime un artiste
@app.delete("/artistes/{artiste_id}")
async def delete_artiste(artiste_id: int, session: db.Session = Depends(db.get_session)) :
  return delete(artiste_id, db.Artiste, session)


# Supprime un album
@app.delete("/albums/{album_id}")
async def delete_album(album_id: int, session: db.Session = Depends(db.get_session)) :
  return delete(album_id, db.Album, session)


# Supprime un genre
@app.delete("/genres/{genre_id}")
async def delete_genre(genre_id: int, session: db.Session = Depends(db.get_session)) :
  return delete(genre_id, db.Genre, session)
