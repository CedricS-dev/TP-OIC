# *******************************************************
# Nom ......... : screenshots.py
# Rôle ........ : Programme lançant selenium sur l'API du Met Museum
# Auteur ...... : Cedric SAGHI
# Version ..... : V0.1 du 10/04/2025
# Licence ..... : Réalisé dans le cadre du cours outils collaboratifs, chapitre 2, L1 informatique
# (../..)
# Compilation : aucune
# Usage : Pour exécuter : python3 screenshots.py
# ********************************************************/


from selenium import webdriver
from selenium.webdriver import ChromeOptions
import requests
import json


# Nom de l'artiste à rechercher, à modifier au besoin
artiste ="Picasso"


def formate_nom(nom:str) -> str :
  """Formate la chaîne de caractères en argument pour que chaque mot soit en minuscule
  et commence par une majuscule.

  Args:
      nom (str): Chaîne de caractères à formater

  Returns:
      str: Chaîne de caractères formatée
  """
  result = []
  # Découpe la chaîne selon les espaces
  nom = nom.strip()
  noms = nom.split(' ')
  # Pour chaque mot dans la liste
  for mot in noms: 
    # Si le mot n'est pas un espace ou une chaîne vide
    if mot != ' ' and mot != '' :
      # Met le mot en minuscule, et la première lettre en majuscule
      # Et ajoute ce mot dans la liste result
      result.append(mot.lower().capitalize())
  # Retourne la liste de mot sous forme de chaîne de caractères
  return " ".join(result)


def recherche_artiste(artiste:str) -> list | bool :
  """Lance une recherche sur l'API du Met Museum à partir de la chaîne de caractère donnée en argument.

  Args:
      artiste (str): Mot(s) à rechercher

  Returns:
      list | bool: Liste des IDs des œuvres correspondantes, ou False si aucun résultat
  """
  # Formate la chaîne donnée en argument 
  artiste = formate_nom(artiste)
  url = f"https://collectionapi.metmuseum.org/public/collection/v1/search?artistOrCulture=true&q={artiste}"
  # Lance la recherche sur l'API
  r = requests.get(url)
  # Enregistre la réponse et récupère les IDs
  reponse = r.json()
  # Si la liste de réponse est vide, retourne False, sinon retourne la liste d'IDs
  if reponse["total"] == 0 :
    return False
  else :
    return reponse["objectIDs"]


def prend_screenshots(artiste: str, limite: int = 10) -> None :
  """Prends des screenshots de chaque page générée à partir d'une liste d'identifiants sur le site Met Museum
  et crée un fichier JSON contenant les informations correspondantes.

  Args:
      artiste (str): Mot(s) à rechercher
      limite (int): Limite du nombre de screenshots à prendre (10 par défaut)
  """
  # Lance la recherche d'œuvres
  id_list = recherche_artiste(artiste)
  # Si la fonction recherche_artiste() a retournée False
  # retourne un message d'erreur et arrête le programme
  if id_list == False :
    print(f"Aucun résultat n’a été trouvé pour la rechrche {artiste}")
    return
  
  # Lance le driver Chrome
  options = ChromeOptions()
  options.add_argument("--headless=new")
  driver = webdriver.Chrome(options=options)

  result = []
  elements = {"artiste": "artistDisplayName",
            "titre": "title",
            "date": "objectDate",
            "dimensions": "dimensions",
            "medium": "medium"}
  # Pour chaque ID dans la liste
  for index, id in enumerate(id_list) :
    # Construit l'url de la requête de l'API
    api_oeuvre = f"https://collectionapi.metmuseum.org/public/collection/v1/objects/{id}"
    # Lance la requête sur cette url
    r_data = requests.get(api_oeuvre)
    data = r_data.json()
    # Récupère l'url de la page du site Met Museum et affiche la page correspondante
    url_oeuvre = data["objectURL"]
    driver.get(url_oeuvre)
    # Prends un screenshot
    screenshot_name =  f"{artiste}-{index + 1}.png"
    driver.save_screenshot(screenshot_name)
    # Et enregistre les informations suivantes dans le dictionnaire
    dict_oeuvre = {}
    for key, value in elements.items() :
      dict_oeuvre["url"] = url_oeuvre
      dict_oeuvre["screenshot"] = screenshot_name
      dict_oeuvre[key] = data[value]
   
    result.append(dict_oeuvre)

    # Affiche un message à l'utilisateur pour l'informer de l'avancement du programme
    print(f"Le screenshot {dict_oeuvre["screenshot"]} a été enregistré...")
    # Si la limite est atteinte, arrête-toi
    if index == limite - 1 :   
      break
  
  # Enregiste les dictionnaires dans le fichier data.json
  # Puis ferme le driver et retourne un message à l'utilisateur
  with open("data.json", "w") as file :
    json.dump(result, file)
    
  driver.close()
  print("Fin du programme.")


prend_screenshots(artiste)