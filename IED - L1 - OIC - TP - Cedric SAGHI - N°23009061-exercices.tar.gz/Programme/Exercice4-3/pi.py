#********************************************************
# Nom ......... : pi.py
# Rôle ........ : Code Python pour l'application Streamlit du bonus 4.3 du cour OC
# Auteur ...... : Cedric SAGHI
# Version ..... : V0.1 du 24/06/2025
# Licence ..... : Réalisé dans le cadre du cours outils collaboratifs, chapitre 4, L1 informatique
# (../..)
# Compilation : aucune
# Usage : Pour exécuter : streamlit run pi.py
#******************************************************** 


from mpmath import mp
import streamlit as st
from os import path
from datetime import datetime


def get_pi_decimals(precision:int) :
  """Imprime dans un fichier les décimales de pi jusqu'à une décimale donnée en argument.

  Args:
      precision (int): nombre de décimales à récupérer
  """
  # Donne au module mpmath le nombre donné en argument comme précision sur les nombres flottant
  mp.dps = precision
  # Calcule pi avec cette précision et convertit le résultat en string
  pi_value = str(mp.pi)
  # Suprime les deux premier caractères (3.)
  pi_value = pi_value[2:]
  # Et imprime le résultat dans le fichier
  with open("pi_decimales.txt", "w") as file :
    print(pi_value, file=file)


# Si le fichier "pi_decimales.txt" n'existe pas ou est vide, crée le
if not path.exists("pi_decimales.txt") or path.getsize("pi_decimales.txt") == 0 :
  get_pi_decimals(1000000)

# Récupère les décimales de pi dans une variable globale
with open("pi_decimales.txt", "r") as pi :
  DECIMALES = pi.readline()


def recherche_date(date:str, decimales:str) :
  """Recherche une date dans une chaîne de caractères et imprime le résultat dans une application Streamlit.

  Args:
      date (str): Date à rechercher sous forme de string
      decimales (str): Chaîne de caractères où lancer la recherche
  """
  # Dictionnaire pour convertir les jours anglais en jours français
  jour_semaine = {
    'Monday': 'lundi',
    'Tuesday': 'mardi',
    'Wednesday': 'mercredi',
    'Thursday': 'jeudi',
    'Friday': 'vendredi',
    'Saturday': 'samedi',
    'Sunday': 'dimanche'
  }
  # Liste de mois de l'année, le premier élément est vide afin que 'Janvier' soit à l'indice 1
  mois = ['' ,'janvier', 'février', 'mars', 'avril', 
          'mai', 'juin', 'juillet', 'août', 'septembre',
          'octobre', 'novembre', 'décembre'
  ]

  # Converti la date récupérée en string sans symbole 
  str_date = f"{date.day}{date.month}{date.year}"
  # Récupère le jour
  day = date.strftime("%A")
  # Recherche dans la liste des décimales de pi la date (+1, car la première décimale est à l'indice 0)
  try :
    recherche = decimales.index(str_date) + 1
    st.write(f"La date de naissance du {jour_semaine[day]} {date.day} {mois[date.month]} {date.year} apparaît à l'indice {recherche}.")
  # Si la date n'a pas été trouvée, imprime ce message
  except ValueError :
    st.write("Cette date n'est pas présente dans le premier million de décimales de pi.")


st.title("Exercice Bonus 4.3")
st.subheader("Recherche de date de naissance dans le premier million des décimales de pi", divider=True)

# La date est récupérée dans une input de type date
date = st.date_input("Entrez une date de naissance :", format='DD/MM/YYYY')

# Puis elle est donnée à la fonction recherche_date()
recherche_date(date, DECIMALES)
    

def somme_decimales_pi(quantite:int, decimales:str) -> int :
  """Calcule la somme des décimales de pi jusqu'à une décimale donnée.

  Args:
      quantite (int): Nombre de décimale à additionner
      decimales (str): Chaîne de caractère contenant les décimales de pi
  """
  result = 0
  for i in range(quantite) :
    result = result + int(decimales[i])
  
  st.write(f"Somme des {quantite} premières décimales de pi est égale à {result}")
  return result

# Une fonction permet de calculer la somme des décimales
st.subheader("Somme des décimales de pi", divider=True)
somme_decimales_pi(20, DECIMALES)
somme_decimales_pi(12**2, DECIMALES)



# Ajoute la vidéo dans la page Streamlit
st.subheader("Vidéo démontrant que la somme des entiers naturels est égale à -1/12", divider=True)
st.video("https://youtu.be/GnZQOb9YNV4")